 let updateAccountNameFilter =  value => ({ type:"UPDATE_NAME_FILTER",  value})

 let updateTransactionTypeFilter = value => ({ type:"UPDATE_TYPE_FILTER",  value})

 export {updateAccountNameFilter, updateTransactionTypeFilter};